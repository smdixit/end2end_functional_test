#define LINKED_LIST_C

#include "stdio.h"
#include "stdlib.h"
#include "linked_list.h"

void Callout_one(void)
{
	printf("Callout_sucess_through_grace\n");
}
