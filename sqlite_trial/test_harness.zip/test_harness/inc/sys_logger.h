#define TRACE_HP_EVENT(x, y) do{}while(0);
#define TRACE_LP_EVENT(x, y) do{}while(0);