#include <stdio.h>
#define SKIP_MAGIC_NUMBER 1
#include "linked_list.h"

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;


int main(void)
{
	printf("Ready 123!!.\n");
	Callout_one();
	SetTimeSinceEpoch();
	(void) RCtHWSWC_Displays_MainFunction()	;
	
	return 0;
}
